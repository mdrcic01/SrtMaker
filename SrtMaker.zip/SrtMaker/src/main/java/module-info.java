module com.srtmaker.srtmaker {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.media;

    opens com.srtmaker.srtmaker to javafx.fxml;
    exports com.srtmaker.srtmaker;
}