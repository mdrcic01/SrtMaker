package com.srtmaker.srtmaker;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloController {
    @FXML
    public Button newProjectBtn;

    @FXML
    public void onBtnClick() throws IOException {
        Stage stage = HelloApplication.getMainStage();
        FXMLLoader loader = new FXMLLoader(HelloController.class.getResource("project.fxml"));
        Scene scene = new Scene(loader.load(), 700, 500);
        stage.setScene(scene);
        stage.show();
    }
}