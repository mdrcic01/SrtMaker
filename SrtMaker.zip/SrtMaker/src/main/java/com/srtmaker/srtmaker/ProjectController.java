package com.srtmaker.srtmaker;

import javafx.animation.Animation;
import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.css.converter.DurationConverter;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.event.EventType;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.media.Media;
import javafx.scene.media.MediaErrorEvent;
import javafx.scene.media.MediaPlayer;
import javafx.scene.media.MediaView;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;
import javafx.util.converter.TimeStringConverter;

import java.io.*;
import java.nio.file.Path;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.Timer;
import java.util.concurrent.TimeUnit;

public class ProjectController {
    Stage chooserStage = new Stage();
    Stage mainStage = HelloApplication.getMainStage();
    String currentTime;
    String startTime;
    String endTime;
    Integer subtitleNo;
    @FXML
    public MediaView mediaView;
    @FXML
    public Button playButton;
    @FXML
    public Label startTimeL;
    @FXML
    public Label endTimeL;
    @FXML
    public Label durationL;
    @FXML
    public TextArea subs;
    @FXML
    public Button rewind1s;
    @FXML
    public Button rewind100ms;
    @FXML
    public Button forward1s;
    @FXML
    public Button forward100ms;
    @FXML
    public Label subNoL;


    @FXML
    public void initialize(){

    }

    public void setRewind1s(){
        Duration dur = mediaView.getMediaPlayer().getCurrentTime();
        mediaView.getMediaPlayer().seek(dur.subtract(Duration.seconds(1)));
    }
    public void setRewind100ms(){
        Duration dur = mediaView.getMediaPlayer().getCurrentTime();
        mediaView.getMediaPlayer().seek(dur.subtract(Duration.millis(100)));
    }
    public void setForward1s(){
        Duration dur = mediaView.getMediaPlayer().getCurrentTime();
        mediaView.getMediaPlayer().seek(dur.add(Duration.millis(1000)));
    }
    public void setForward100ms(){
        Duration dur = mediaView.getMediaPlayer().getCurrentTime();
        mediaView.getMediaPlayer().seek(dur.add(Duration.millis(100)));
    }

    public void onAddTamplateClick(){
        //open file chooser
        FileChooser fc = new FileChooser();
        File video = fc.showOpenDialog(chooserStage);
        String videoPath = video.getAbsolutePath();
        Media media = new Media(new File(videoPath).toURI().toString());
        MediaPlayer mp = new MediaPlayer(media);
        //mediaView = new MediaView(mp);
        mediaView.setMediaPlayer(mp);
        subtitleNo = 1;
        Timeline timeline = new Timeline(new KeyFrame(Duration.millis(100), new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent actionEvent) {
                Duration duration = mediaView.getMediaPlayer().getCurrentTime();
                String time = String.format("%02d:%02d:%02d",
                        (int) duration.toHours(),
                        (int) duration.toMinutes() % 60,
                        (int) duration.toSeconds() % 3600);
                durationL.setText(time);
            }
        }), new KeyFrame(Duration.millis(100)));
        timeline.setCycleCount(Animation.INDEFINITE);
        timeline.play();
    }

    public void onNextSubClick(){
        StringBuilder errors = new StringBuilder("");
        Optional<String> tempStart;
        tempStart = Optional.ofNullable(startTime);
        if(tempStart.isEmpty()){
            errors.append("Start time must be set!\n");
        }
        Optional<String> tempEnd;
        tempEnd = Optional.ofNullable(endTime);
        if(tempStart.isEmpty()){
            errors.append("End time must be set!\n");
        }
        String subtitle = subs.getText();
        if(subtitle.isEmpty()){
            errors.append("Subtitle must be present!");
        }
        else{
            subs.clear();
        }
        if(errors.isEmpty()){
            //add subtitle to srt file
            try(PrintWriter writer = new PrintWriter(new FileWriter("srt.srt", true))) {
                writer.println(subtitleNo);
                writer.printf("%s --> %s\n", tempStart.get(), tempEnd.get());
                writer.println(subtitle);
                writer.println();
            } catch (IOException e) {
                e.printStackTrace();
            }
            subtitleNo++;
            subNoL.setText("Subtitle No: " + subtitleNo);
        }
        else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Input error!");
            alert.setContentText(errors.toString());
            alert.showAndWait();
        }
    }

    public void onSaveSubsClick(){
        File file = new File("srt.srt");
        FileChooser fc = new FileChooser();
        FileChooser.ExtensionFilter extFilter = new FileChooser.ExtensionFilter("SRT files (*.srt)", "*.srt");
        fc.getExtensionFilters().add(extFilter);
        File saveFile = fc.showSaveDialog(chooserStage);
        file.renameTo(saveFile);
        file.delete();

    }

    public void onKeyPressed(KeyEvent ke){
        switch(ke.getCode()){
            case SPACE -> {
                if(mediaView.getMediaPlayer().getStatus().equals(MediaPlayer.Status.PLAYING)){
                    onPause();
                }
                else{
                    onPlay();
                }
            }
            case LEFT -> {
                Duration dur = mediaView.getMediaPlayer().getCurrentTime();
                mediaView.getMediaPlayer().seek(dur.subtract(Duration.seconds(5)));
            }
            case RIGHT -> {
                Duration dur = mediaView.getMediaPlayer().getCurrentTime();
                mediaView.getMediaPlayer().seek(dur.add(Duration.seconds(5)));
            }
        }
    }

    public void onPlay(){
        mediaView.getMediaPlayer().play();
    }
    public void onPause(){
        mediaView.getMediaPlayer().pause();
    }
    public void onSetStart(){
        Duration duration = mediaView.getMediaPlayer().getCurrentTime();
        currentTime = String.format("%02d:%02d:%02.3f",
                (int) duration.toHours(),
                (int) duration.toMinutes() % 60,
                duration.toSeconds() % 3600);
        System.out.println(currentTime);
        startTime = currentTime;
        startTimeL.setText(currentTime);
    }
    public void onSetEnd(){
        Duration duration = mediaView.getMediaPlayer().getCurrentTime();
        currentTime = String.format("%02d:%02d:%02.3f",
                (int) duration.toHours(),
                (int) duration.toMinutes() % 60,
                duration.toSeconds() % 3600);
        System.out.println(currentTime);
        endTime = currentTime;
        endTimeL.setText(currentTime);
    }
}
